# Stackly Sign Up & Sign In Prototype

Mini prototype for the **Stackly Enterprise Data Analytics & Business Intelligence Platform**.

## Tech

- HTML5
- CSS3
- Vanilla JavaScript
- No frameworks
- No UI libraries
- No backend

## Folder structure

```text
edabip-signup/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── assets/
```

## Run locally

### Option 1 — Open directly

Double-click `index.html`.

### Option 2 — VS Code Live Server

Open the project in VS Code and run `index.html` with Live Server.

### Option 3 — Python local server

```bash
python -m http.server 5500
```

Then open:

```text
http://localhost:5500
```

## Implemented interactions

- Sign up / Log in tab state
- Form validation
- Password show/hide
- Confirm password validation
- Terms checkbox
- Create Account enabled/disabled state
- Sample account creation using JavaScript
- Social sign-up placeholder actions
- Contact Support link
- Responsive desktop/tablet/mobile layout
- Keyboard focus states
- Accessible labels and ARIA attributes

## Sample validation

Password requires:

- Minimum 8 characters
- One uppercase letter
- One lowercase letter
- One number

## What was difficult

The main challenge was reproducing the Figma layout closely while keeping the implementation framework-free. The design combines a dark analytics/security background, a centered authentication card, responsive behavior, and several interactive form states. The background security illustration is implemented with CSS shapes so the prototype remains self-contained without external UI libraries.

## Suggested commits

```text
Day 1: feat: create EDABIP signup page structure
Day 2: feat: match signup design and add responsive styles
Day 2: feat: add signup validation and password interactions
Day 3: docs: add README and polish responsive UI
```
