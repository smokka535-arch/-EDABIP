const form = document.getElementById("signupForm");
const terms = document.getElementById("terms");
const createAccount = document.getElementById("createAccount");
const toast = document.getElementById("toast");

const fields = {
  firstName: document.getElementById("firstName"),
  lastName: document.getElementById("lastName"),
  email: document.getElementById("email"),
  password: document.getElementById("password"),
  confirmPassword: document.getElementById("confirmPassword")
};

const errors = {
  firstName: document.getElementById("firstNameError"),
  lastName: document.getElementById("lastNameError"),
  email: document.getElementById("emailError"),
  password: document.getElementById("passwordError"),
  confirmPassword: document.getElementById("confirmPasswordError")
};

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3000);
}

function setError(name, message) {
  const input = fields[name];
  errors[name].textContent = message;
  input.classList.toggle("input-error", Boolean(message));
}

function validateField(name) {
  const value = fields[name].value.trim();

  if (name === "firstName" || name === "lastName") {
    if (!value) {
      setError(name, "This field is required.");
      return false;
    }
    if (!/^[a-zA-Z][a-zA-Z .'-]{1,39}$/.test(value)) {
      setError(name, "Please enter a valid name.");
      return false;
    }
  }

  if (name === "email") {
    if (!value) {
      setError(name, "Email is required.");
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      setError(name, "Enter a valid email address.");
      return false;
    }
  }

  if (name === "password") {
    if (!value) {
      setError(name, "Password is required.");
      return false;
    }
    if (value.length < 8) {
      setError(name, "Use at least 8 characters.");
      return false;
    }
    if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value)) {
      setError(name, "Use uppercase, lowercase and a number.");
      return false;
    }
  }

  if (name === "confirmPassword") {
    if (!value) {
      setError(name, "Please confirm your password.");
      return false;
    }
    if (value !== fields.password.value) {
      setError(name, "Passwords do not match.");
      return false;
    }
  }

  setError(name, "");
  return true;
}

function updateSubmitState() {
  const complete =
    Object.values(fields).every((field) => field.value.trim()) &&
    terms.checked;

  createAccount.disabled = !complete;
}

Object.keys(fields).forEach((name) => {
  fields[name].addEventListener("blur", () => {
    validateField(name);
    updateSubmitState();
  });

  fields[name].addEventListener("input", () => {
    if (errors[name].textContent) {
      validateField(name);
    }
    updateSubmitState();
  });
});

terms.addEventListener("change", () => {
  document.getElementById("termsError").textContent = terms.checked
    ? ""
    : "Please accept the terms.";
  updateSubmitState();
});

document.querySelectorAll(".password-toggle").forEach((button) => {
  button.addEventListener("click", () => {
    const input = document.getElementById(button.dataset.target);
    const isPassword = input.type === "password";
    input.type = isPassword ? "text" : "password";
    button.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
  });
});

const loginForm = document.getElementById("loginForm");
const loginEmail = document.getElementById("loginEmail");
const loginPassword = document.getElementById("loginPassword");
const loginEmailError = document.getElementById("loginEmailError");
const loginPasswordError = document.getElementById("loginPasswordError");

function switchMode(mode) {
  const signupTab = document.getElementById("signupTab");
  const loginTab = document.getElementById("loginTab");
  const signupTitle = document.getElementById("signup-title");
  const signupSubtitle = document.getElementById("signupSubtitle");
  const promptText = document.getElementById("promptText");
  const toggleAuthMode = document.getElementById("toggleAuthMode");
  const socialDividerText = document.getElementById("socialDividerText");

  if (mode === "login") {
    loginTab.classList.add("active");
    signupTab.classList.remove("active");
    loginTab.setAttribute("aria-selected", "true");
    signupTab.setAttribute("aria-selected", "false");

    signupForm.classList.add("hidden-form");
    loginForm.classList.remove("hidden-form");

    if (signupTitle) signupTitle.textContent = "Welcome Back";
    if (signupSubtitle) signupSubtitle.textContent = "Sign in to continue to your dashboard and accelerate your analytics journey";
    if (promptText) promptText.textContent = "Don't have an account?";
    if (toggleAuthMode) toggleAuthMode.textContent = "Sign up";
    if (socialDividerText) socialDividerText.textContent = "or sign in with";
  } else {
    signupTab.classList.add("active");
    loginTab.classList.remove("active");
    signupTab.setAttribute("aria-selected", "true");
    loginTab.setAttribute("aria-selected", "false");

    loginForm.classList.add("hidden-form");
    signupForm.classList.remove("hidden-form");

    if (signupTitle) signupTitle.textContent = "Create Account";
    if (signupSubtitle) signupSubtitle.textContent = "Sign up to access your dashboard and accelerate your analytics journey";
    if (promptText) promptText.textContent = "Already have an account?";
    if (toggleAuthMode) toggleAuthMode.textContent = "Login";
    if (socialDividerText) socialDividerText.textContent = "or sign up with";
  }
}

document.getElementById("signupTab").addEventListener("click", () => switchMode("signup"));
document.getElementById("loginTab").addEventListener("click", () => switchMode("login"));

const toggleAuthModeBtn = document.getElementById("toggleAuthMode");
if (toggleAuthModeBtn) {
  toggleAuthModeBtn.addEventListener("click", () => {
    const isLoginActive = loginForm.classList.contains("hidden-form");
    switchMode(isLoginActive ? "login" : "signup");
  });
}

document.getElementById("termsLink").addEventListener("click", (event) => {
  event.preventDefault();
  showToast("Terms & Conditions would open here.");
});

const forgotPasswordLink = document.getElementById("forgotPasswordLink");
if (forgotPasswordLink) {
  forgotPasswordLink.addEventListener("click", (event) => {
    event.preventDefault();
    const email = loginEmail.value.trim();
    if (email) {
      showToast(`Password reset link sent to ${email}`);
    } else {
      showToast("Please enter your email above to receive a reset link.");
    }
  });
}

document.querySelectorAll(".social-button").forEach((button) => {
  button.addEventListener("click", () => {
    showToast("Social authentication connected successfully in demo mode.");
  });
});

// Signup form submission
form.addEventListener("submit", (event) => {
  event.preventDefault();

  const valid = Object.keys(fields).map(validateField).every(Boolean);

  if (!terms.checked) {
    document.getElementById("termsError").textContent = "Please accept the terms.";
  }

  if (!valid || !terms.checked) {
    updateSubmitState();
    showToast("Please check the highlighted fields.");
    return;
  }

  const user = {
    firstName: fields.firstName.value.trim(),
    lastName: fields.lastName.value.trim(),
    email: fields.email.value.trim()
  };

  showToast(`Welcome, ${user.firstName}! Account created successfully.`);
  form.reset();
  updateSubmitState();
});

// Login form submission & validation
if (loginForm) {
  function validateLoginEmail() {
    const value = loginEmail.value.trim();
    if (!value) {
      loginEmailError.textContent = "Email is required.";
      loginEmail.classList.add("input-error");
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      loginEmailError.textContent = "Enter a valid email address.";
      loginEmail.classList.add("input-error");
      return false;
    }
    loginEmailError.textContent = "";
    loginEmail.classList.remove("input-error");
    return true;
  }

  function validateLoginPassword() {
    const value = loginPassword.value;
    if (!value) {
      loginPasswordError.textContent = "Password is required.";
      loginPassword.classList.add("input-error");
      return false;
    }
    loginPasswordError.textContent = "";
    loginPassword.classList.remove("input-error");
    return true;
  }

  loginEmail.addEventListener("blur", validateLoginEmail);
  loginEmail.addEventListener("input", () => {
    if (loginEmailError.textContent) validateLoginEmail();
  });

  loginPassword.addEventListener("blur", validateLoginPassword);
  loginPassword.addEventListener("input", () => {
    if (loginPasswordError.textContent) validateLoginPassword();
  });

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const isEmailValid = validateLoginEmail();
    const isPasswordValid = validateLoginPassword();

    if (!isEmailValid || !isPasswordValid) {
      showToast("Please enter your email and password.");
      return;
    }

    showToast(`Signed in successfully as ${loginEmail.value.trim()}`);
  });
}

updateSubmitState();
